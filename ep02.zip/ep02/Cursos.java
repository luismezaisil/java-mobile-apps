import java.util.ArrayList;

public class Cursos {
    private final ArrayList<Cursos> Cursos;

    public Cursos() {
        Cursos = new ArrayList<Cursos>();
    }

    public void agregarCurso(Cursos Curso) {
        Cursos.add(Curso);
    }

    public void removeBook(Cursos Curso) {
        Cursos.remove(Curso);
    }

    public ArrayList<Cursos> getCurso() {
        return Cursos;
    }

    public int booksQuantity() {
        return Cursos.size();
    }

    public void showBooks() {
        for (int i = 0; i <= booksQuantity() - 1; i++) {
            Cursos book = Cursos.get(i);
            System.out.println(book.getCurso());
        }
    }

}